using System;

internal class Hipster
{
    public int Money { get; set; }
    public int Donate { get; set; }
    public Hipster(int money, int donate)
    {
        Money = money;
        Donate = donate;
    }
}